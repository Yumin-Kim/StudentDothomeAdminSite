* 매개 변수 
    * $0 실행시킨 스크립트 명
    * $1-$9 매개 변수
    * %@ 전달 받은 arguement 수
    * $? 실행 명령문의 result을 받아 온다. >> 종료 여부 확인
    * $$ 현 스크립트의 프로세스 ID 확인
* Global variable    
기존에 존재하는 전역 변수 
    * $USER
    * $HOSTNAME
    * $RANDOM
* 